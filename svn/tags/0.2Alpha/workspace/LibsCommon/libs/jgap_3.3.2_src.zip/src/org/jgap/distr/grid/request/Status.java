package org.jgap.distr.grid.request;

import java.io.*;

public class Status
    implements Serializable {
  public int code;

  public String description;

  public byte[] buffer;
}
