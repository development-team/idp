package org.jgap.distr.grid.request;

import java.io.*;

public class VersionInfo
    implements Serializable {
  public String currentVersion;

  public String filenameOfLib;

  public String libName;
}
