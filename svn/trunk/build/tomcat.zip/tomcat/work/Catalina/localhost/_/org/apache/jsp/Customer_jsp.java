package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class Customer_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<title>Customers list</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("\r\n");
      java.util.ArrayList<core.Customer> customers = null;
      synchronized (request) {
        customers = (java.util.ArrayList<core.Customer>) _jspx_page_context.getAttribute("customers", PageContext.REQUEST_SCOPE);
        if (customers == null){
          throw new java.lang.InstantiationException("bean customers not found within scope");
        }
      }
      out.write("\r\n");
      out.write("\r\n");
      out.write("<b>Registered Customers:</b><br>\r\n");
      out.write("<table border=\"1\">\r\n");
      out.write("<tr>\r\n");
      out.write("\t<th>ID</th>\r\n");
      out.write("\t<th>First Name</th>\r\n");
      out.write("\t<th>Last Name</th>\r\n");
      out.write("\t<th>Address</th>\r\n");
      out.write("\t<th>Orders</th>\r\n");
      out.write("</tr>\r\n");
 for(core.Customer c : customers) { 
      out.write("\r\n");
      out.write("<tr>\r\n");
      out.write("\t<td>");
      out.print( c.getId() );
      out.write("</td>\r\n");
      out.write("\t<td>");
      out.print( c.getName() );
      out.write("</td>\r\n");
      out.write("\t<td>");
      out.print( c.getSurname() );
      out.write("</td>\r\n");
      out.write("\t<td>");
      out.print( c.getAddress() );
      out.write("</td>\r\n");
      out.write("\t<td><a href=\"/Orders/ListCustomerOrders?cust_id=");
      out.print( c.getId() );
      out.write("\">Orders</a></td>\r\n");
      out.write("\t</tr>\r\n");
 } 
      out.write("\r\n");
      out.write("\r\n");
      out.write("</table>\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
